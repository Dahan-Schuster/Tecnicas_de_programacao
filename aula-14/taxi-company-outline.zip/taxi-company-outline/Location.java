/**
 * Model a location in a city.
 * 
 * @author David J. Barnes and Michael Kolling
 * @version 2008.03.30
 */
public class Location
{
    /**
     * Constructor for objects of class Location
     */
    public Location()
    {
    }
}
